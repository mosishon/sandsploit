import os , requests
from shutil import copyfile


def upgrade():
        if  os.geteuid() == 0:
                try:
                        option = input ("Are You Want to Full Upgrade SSF ?[Y/n]")
                        if option == "y" or option == "Y" or option == "yes" or option == "Yes":
                                try:
                                        requests.get("https://google.com/")
                                except:
                                        print ("Please Check Your Internet Connections")
                                os.system("git clone https://github.com/auip_0x0/sandsploit.git")
                                src = "sandsploit/*"
                                dst = "/opt/sandsploit/"
                                copyfile(src, dst)
                                print ("Successful. :)")
                        else:
                                print ("Cancelled.... :( ")
                except:
                        print ("Unknown Error!!!")
        else:
                print ("Please Run Sandsploit with root user to Starting Update...!")
                