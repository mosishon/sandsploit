def version():
    print ("2.0") 
